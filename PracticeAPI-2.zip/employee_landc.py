import time
class employee_test:
  def deductive1():
    s = input("DQuestion1 ")
    if(int(s) == 3):
      return int(1)
    else:
      return int(0)
  def deductive2():
    s = input("DQuestion2 ")
    if(int(s) == 4):
      return int(1)
    else:
      return int(0)
  def deductive3():
    s = input("DQuestion3 ")
    if(int(s) == 1):
      return int(1)
    else:
      return int(0)
  def inductive1():
    s = input("IQuestion1 ")
    if(int(s) == 3):
      return int(1)
    else:
      return int(0)
  def inductive2():
    s = input("IQuestion2 ")
    if(int(s) == 2):
      return int(1)
    else:
      return int(0)
  def inductive3():
    s = input("IQuestion3 ")
    if(int(s) == 3):
      return int(1)
    else:
      return int(0)
  def creative1():
    s = {"actor","falling","dust"}
    start_time = time.time()
    s1 = str(input("Word1 "))
    end_time = time.time() - start_time
    c_percent = 0
    for i in s:
      if(s1.upper() == "STAR"):
        c_percent = c_percent + 1
    if(end_time > 30 and end_time < 90):
      if(c_percent != 0):
        c_percent = c_percent - 1
    elif(end_time >= 90 and end_time < 120):
      if(c_percent > 1):
        c_percent = c_percent - 2
      else:
        c_percent = 0
    elif(end_time >= 120):
      c_percent = 0
    else:
      c_percent = c_percent
    return c_percent
  def creative2():
    s = {"cube","cream","cap"}
    start_time = time.time()
    s1 = str(input("Word2 "))
    end_time = time.time() - start_time
    c_percent = 0
    for i in s:
      if(s1.upper() == "ICE"):
        c_percent = c_percent + 1
    if(end_time > 30 and end_time < 90):
      if(c_percent != 0):
        c_percent = c_percent - 1
    elif(end_time >= 90 and end_time < 120):
      if(c_percent > 1):
        c_percent = c_percent - 2
      else:
        c_percent = 0
    elif(end_time >= 120):
      c_percent = 0
    else:
      c_percent = c_percent
    return c_percent
  def creative3():
    s = {"glasses","screen","day"}
    start_time = time.time()
    s1 = str(input("Word3 "))
    end_time = time.time() - start_time
    c_percent = 0
    for i in s:
      if(s1.upper() == "SUN"):
        c_percent = c_percent + 1
    if(end_time > 30 and end_time < 90):
      if(c_percent != 0):
        c_percent = c_percent - 1
    elif(end_time >= 90 and end_time < 120):
      if(c_percent > 1):
        c_percent = c_percent - 2
      else:
        c_percent = 0
    elif(end_time >= 120):
      c_percent = 0
    else:
      c_percent = c_percent
    return c_percent
  def creative4():
    s = {"knife","fly","cup"}
    start_time = time.time()
    s1 = str(input("Word4 "))
    end_time = time.time() - start_time
    c_percent = 0
    for i in s:
      if(s1.upper() == "BUTTER"):
        c_percent = c_percent + 1
    if(end_time > 30 and end_time < 90):
      if(c_percent != 0):
        c_percent = c_percent - 1
    elif(end_time >= 90 and end_time < 120):
      if(c_percent > 1):
        c_percent = c_percent - 2
      else:
        c_percent = 0
    elif(end_time >= 120):
      c_percent = 0
    else:
      c_percent = c_percent
    return c_percent
  def creative5():
    s = {"cake","swiss","cottage"}
    start_time = time.time()
    s1 = str(input("Word5 "))
    end_time = time.time() - start_time
    c_percent = 0
    for i in s:
      if(s1.upper() == "CHEESE"):
        c_percent = c_percent + 1
    if(end_time > 30 and end_time < 90):
      if(c_percent != 0):
        c_percent = c_percent - 1
    elif(end_time >= 90 and end_time < 120):
      if(c_percent > 1):
        c_percent = c_percent - 2
      else:
        c_percent = 0
    elif(end_time >= 120):
      c_percent = 0
    else:
      c_percent = c_percent
    return c_percent
  

  