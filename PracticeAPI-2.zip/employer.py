import Employers_Class
class valid_jobs: # examples of databases
  def __init__(self,number = 0):
    self.number = number
    self.arr = []
    self.arr.append(Employers_Class.employer_class("HSBC",["Extrovert".upper(),"Intuitive".upper(),"Thinking".upper(),"Judging".upper(),"Assertive".upper()],8,2))
    self.arr.append(Employers_Class.employer_class("NHS",["Extrovert".upper(),"Intuitive".upper(),"Feeling".upper(),"Perceiving".upper(),"Assertive".upper()],5,5))
    self.arr.append(Employers_Class.employer_class("Frazer Nash Consultancy - Developer",["Introvert".upper(),"Intuitive".upper(),"Thinking".upper(),"Judging".upper(),"Turbulent".upper()],7,3))
    self.number = 3
    
  def job(self):
    # where employer specifies what all he is looking for in a potential employee 
    Name = input("Company Name:")
    s = input("Personalities:")
    Personalities = (s.split(","))
    Logic = input("Logic%:")
    Creative = input("Creative%:")
    self.arr.append(Employers_Class.employer_class(Name,Personalities,Logic,Creative))
    self.number = self.number+1




  
    