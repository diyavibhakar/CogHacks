import employer
import employee_personality
import employee_landc
s = input("Name ")
employer.valid_jobs()
arr = []
print("\nEandI")
arr.append(employee_personality.employee_test.extrovert_introvert())
print("\nIandO")
arr.append(employee_personality.employee_test.intuitive_observant())
print("\nTandF")
arr.append(employee_personality.employee_test.thinking_feeling())
print("\nJandP")
arr.append(employee_personality.employee_test.judging_perceiving())
print("\nAandT")
arr.append(employee_personality.employee_test.assertive_turbulent())    
Pers = arr
print(Pers)
print("Deductive and Inductive")
cnt = (int(employee_landc.employee_test.deductive1() )+ int(employee_landc.employee_test.deductive2() )+ int(employee_landc.employee_test.deductive3() )+ int(employee_landc.employee_test.inductive1() )+ int(employee_landc.employee_test.inductive2() )+ int(employee_landc.employee_test.inductive3()))
cnt = (cnt/6.0) * 100
print("COUNT LOGIC percent",cnt)
print("Creative")
cnt1 = employee_landc.employee_test.creative1() + employee_landc.employee_test.creative2() + employee_landc.employee_test.creative3() + employee_landc.employee_test.creative4() + employee_landc.employee_test.creative5()
print("COUNT CREATIVE",cnt1)  
cnt1 = (cnt1/15.0)*100
print("count creative percent",cnt1)
if(cnt + cnt1) == 0:
  Logic = 0
  Creative = 0
else:
  Logic = (int(cnt)/int(cnt + cnt1 ) )* 100
  Creative = (int(cnt1)/int(cnt + cnt1)) * 100
print("\nPersonality:",Pers)
print("Logic",Logic)
print("Creative",Creative,"\n")
Checker = employer.valid_jobs()
for i in Checker.arr:
  cnt = i.employee_satisfy(Pers,Logic,Creative)
  print(cnt)
  if(cnt >= 40 ):
    print("Compatable Job",i.name)