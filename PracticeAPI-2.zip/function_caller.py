from PyDictionary import PyDictionary
dictionary = PyDictionary()
def similarity_word(s,s1):
    if(dictionary.meaning(s+s1) != None):
      return True
    if(dictionary.meaning(s1+s) != None):
      return True
    return False