class employer_class:
  def __init__(self,name, personalities,logic,creative):
    self.name = name #name of company
    self.personalities = personalities # personalities employers are looking for
    # how logical or creative they want the employee to be 
    self.logic = logic 
    self.creative = creative

  def employee_satisfy(self, personalities, logic,creative): # calculates percentage of how creative or logical employee is 
    percentage = 0
    for x in range(5):
      print("e",self.personalities[x])
      print("u",personalities[x])
      if self.personalities[x] == personalities[x]:
        percentage = percentage + 100/6
        print(percentage," percentage")
    logic_percent = (logic/100) * 8.333
    creative_percent = (creative/100) * 8.333
    percentage = percentage + logic_percent + creative_percent
    return percentage
  
