class employee_test:
  def extrovert_introvert():
    e_per = 0
    i_per = 0
    s = input("Question 1 ")#would be the choice that the user enters for the first question
    if(int(s) == 1):
      e_per = e_per + 100
    elif(int(s) == 2):
      i_per = i_per + 100
    s = input("Question 2 ")#would be the choice that the user enters for the second question
    if(int(s) == 1):
      e_per = e_per + 100
    elif(int(s) == 2):
      e_per = e_per + 50
      i_per = i_per + 50
    elif(int(s) == 3):
      i_per = i_per + 100
    s = input("Question 3 ")#would be the choice that the user enters for the third question
    if(int(s) == 1):
      i_per = i_per + 100
    elif(int(s) == 2):
      e_per = e_per +100
    e_per = e_per/3
    i_per = i_per/3
    if(e_per > i_per):
      if((e_per - i_per) > 30):
        print()#would be the weakness of an extrovert
      return "EXTROVERT"
    else:
      if(i_per - e_per > 30):
        print()#would be the weakness of an introvert
      return "INTROVERT"
  def intuitive_observant():
    i_per = 0
    o_per=0
    s=input("Question 1 ")#choice that the user enters for the first scenario
    if(int(s)==1):
      o_per=o_per+100
    elif(s==2):
      i_per=i_per+100
    o_per=o_per/2
    i_per=i_per/2
    if(i_per>o_per):
      if(i_per - o_per > 30):
        print()#would be the weakness of an intuitive person
      return "INTUITIVE"
    else:
      return "OBSERVANT"
      if((o_per - i_per) > 30):
        print()#would be the weakness of an observant person
  def thinking_feeling():
    t_per=0
    f_per=0
    s=input("Question 1 ")#choice the user enters for the first scenario
    if(int(s)==1):
      f_per=f_per+100
    elif(int(s)==2):
      t_per=t_per+100   
    s=input("Question 2 ") #choice the user enters for the second scenario
    if(int(s)==1):
      t_per=t_per+75
      f_per=f_per+25
    elif(int(s)==2):
      f_per=f_per+100
    elif(int(s)==3):
      t_per=t_per+100
    s=input("Question 3 ")#choice the user enters for the third scenario
    if(int(s)==1):
      t_per=t_per+20
      f_per=f_per+80
    elif(int(s)==2):
      t_per=t_per+80
      f_per=f_per+20
    elif(int(s)==3):
      t_per=t_per+60
      f_per=f_per+40   
    t_per=t_per/3
    f_per=f_per/3
    if (t_per>f_per):
      if(t_per - f_per > 30):
        print()#would be the weakness of a thinking person
      return "THINKING"
    else:
      if(f_per - t_per > 30):
        print()#would be the weakness of a feeling person
      return "FEELING"
  def judging_perceiving():
    j_per=0
    p_per=0
    s=input("Question 1 ") #choice the user enters for the first scenario
    if(int(s)==1):
      j_per=j_per+100
    elif(int(s)==2):
      p_per=p_per+100
    if(j_per>p_per):
      if(j_per - p_per > 30):
        print()#would be the weakness of a judging person
      return "JUDGING"
    else:
      if(p_per - j_per > 30):
        print()#would be the weakness of a perceiving person
      return "PERCEIVING"
  def assertive_turbulent():
    a_per=0
    t_per=0
    s=input("Question 1 ")#choice the user enters for the first scenario
    if(int(s)==1):
      a_per=a_per+100
    elif(int(s)==2):
      t_per=t_per+100
    if(a_per>t_per):
      if(a_per - t_per > 30):
        print()#would be the weakness of an assertive person
      return "ASSERTIVE"
    else:
      if(t_per - a_per > 30):
        print()#would be the weakness of a turbulent person
      return "TURBULENT"